
# when you import package for the first time, this __init__.py file runs automatically.

print('\nWelcome to my website ;) ', 'https://vixportfoliowithflask.herokuapp.com/skills')

print('\nONLINE MORSE CODE ENCRYPTER AND DECRYPTER : ', 'https://imvickykumar999.github.io/git-bash/')

print('\nUse help(module name) function to know available functions in it.')
